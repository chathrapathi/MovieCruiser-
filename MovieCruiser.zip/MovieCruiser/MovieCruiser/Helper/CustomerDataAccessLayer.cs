﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using MovieCruiser.Models;

namespace MovieCruiser.Helper
{
    public class CustomerDataAccessLayer : ICustomerInterface
    {
        string connectionString = "Data Source=DESKTOP-ITOHQQD; User ID=SA;password=shanthini@123;Initial Catalog = Truyum; Integrated Security = True; Trusted_Connection=True;";

       
        public void AddToFavorite(Movies item)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("INSERT INTO Favorites(Title, BoxOffice,Genre,Active,HasTeaser) VALUES(@Title, @BoxOffice,@Genre,@Active,@HasTeaser)", con);
                command.Parameters.AddWithValue("@Title", item.Title);
                command.Parameters.AddWithValue("@BoxOffice", item.BoxOffice);
                command.Parameters.AddWithValue("@Genre", item.Genre);
                command.Parameters.AddWithValue("@Active", item.Active);
             
                command.Parameters.AddWithValue("@HasTeaser", item.HasTeaser);
               

                con.Open();
                command.ExecuteNonQuery();
                con.Close();
            }
        }
        public Movies GetMovieById(int? id)
        {

            Movies item = new Movies();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string sqlQuery = "SELECT * FROM Movies WHERE ItemId= " + id;
                SqlCommand cmd = new SqlCommand(sqlQuery, con);

                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    item.ItemId = Convert.ToInt32(rdr["ItemId"]);
                    item.Title = rdr["Title"].ToString();
                    item.BoxOffice = rdr["BoxOffice"].ToString();
                    item.Genre = rdr["Genre"].ToString();
                    item.Active = rdr["Active"].ToString();
                    item.HasTeaser = rdr["HasTeaser"].ToString();
                }
            }
            return item;

        }
        public void DeleteFavoriteMovie(int id)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM Favorites WHERE CartId=@CartId", con);


                cmd.Parameters.AddWithValue("@CartId", id);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }

        public List<Favorites> GetFavoriteMovie()
        {
            List<Favorites> cartList = new List<Favorites>();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("select * from Favorites", con);
                con.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Favorites cart = new Favorites();
                    cart.CartId = Convert.ToInt32(reader["CartId"]);
                    cart.Title = reader["Title"].ToString();
                    cart.BoxOffice = reader["BoxOffice"].ToString();
                    cart.Genre = reader["Genre"].ToString();
                    cart.Active = reader["Active"].ToString();
                    cart.HasTeaser= reader["HasTeaser"].ToString();

                    cartList.Add(cart);
                }
                con.Close();
            }
            return cartList;
        }

        public Favorites GetCartItemById(int? cartId)
        {
            Favorites cart = new Favorites();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string sqlQuery = "SELECT * FROM Favorites WHERE CartId= " + cartId;
                SqlCommand cmd = new SqlCommand(sqlQuery, con);

                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    cart.CartId = Convert.ToInt32(rdr["CartId"]);
                    cart.Title = rdr["Title"].ToString();
                    cart.BoxOffice = rdr["BoxOffice"].ToString();
                    cart.Genre = rdr["Genre"].ToString();
                    cart.Active = rdr["Active"].ToString();
       
                    cart.HasTeaser= rdr["HasTeaser"].ToString();
                }
            }
            return cart;
        }
    }
}
