﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MovieCruiser.Models;

namespace MovieCruiser.Helper
{
    interface IAdminInterface
    {
        public List<Movies> GetAllMovies();
        public void AddItem(Movies item);
        public void UpdateItem(Movies item);
        public Movies GetMovieById(int? id);

        public void DeleteMovie(int id);
    }
}
