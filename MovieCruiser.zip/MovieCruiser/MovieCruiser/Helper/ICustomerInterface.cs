﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MovieCruiser.Models;

namespace MovieCruiser.Helper
{
    interface ICustomerInterface
    {
        
        public void AddToFavorite(Movies item);
        public List<Favorites> GetFavoriteMovie();
        public void DeleteFavoriteMovie(int id);
        public Favorites GetCartItemById(int? cartId);
    }
}
