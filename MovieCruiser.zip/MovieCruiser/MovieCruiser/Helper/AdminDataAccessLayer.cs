﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using MovieCruiser.Models;

namespace MovieCruiser.Helper
{
    public class AdminDataAccessLayer : IAdminInterface
    {
        string connectionString = "Data Source=DESKTOP-ITOHQQD; User ID=SA;password=shanthini@123;Initial Catalog = Truyum; Integrated Security = True; Trusted_Connection=True;";
        public void AddItem(Movies item)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("INSERT INTO Movies(Title, BoxOffice,Genre,Active,HasTeaser) VALUES(@Title, @BoxOffice,@Genre,@Active,@HasTeaser)", con);
                command.Parameters.AddWithValue("@Title", item.Title);
                command.Parameters.AddWithValue("@BoxOffice", item.BoxOffice);
                command.Parameters.AddWithValue("@Genre", item.Genre);
                command.Parameters.AddWithValue("@Active", item.Active);
                command.Parameters.AddWithValue("@HasTeaser", item.HasTeaser);

                con.Open();
                command.ExecuteNonQuery();
                con.Close();
            }
        }

        public void DeleteMovie(int id)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM Movies WHERE ItemId=@ItemId", con);
                

                cmd.Parameters.AddWithValue("@ItemId", id);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }

        public List<Movies> GetAllMovies()
        {
            List<Movies> listItem = new List<Movies>();
            using(SqlConnection con=new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("select * from Movies", con);
                con.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Movies item = new Movies();
                    item.ItemId = Convert.ToInt32(reader["ItemId"]);
                    item.Title = reader["Title"].ToString();
                    item.BoxOffice = reader["BoxOffice"].ToString();
                    item.Genre = reader["Genre"].ToString();
                    item.Active = reader["Active"].ToString();
                    item.HasTeaser = reader["HasTeaser"].ToString();

                    listItem.Add(item);
                }
                con.Close();
            }
            return listItem;
        }

        public Movies GetMovieById(int? id)
        {

           Movies item = new Movies();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string sqlQuery = "SELECT * FROM Movies WHERE ItemId= " + id;
                SqlCommand cmd = new SqlCommand(sqlQuery, con);

                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    item.ItemId = Convert.ToInt32(rdr["ItemId"]);
                    item.Title = rdr["Title"].ToString();
                    item.BoxOffice = rdr["BoxOffice"].ToString();
                    item.Genre = rdr["Genre"].ToString();
                    item.Active = rdr["Active"].ToString();
                    item.HasTeaser = rdr["HasTeaser"].ToString();
                }
            }
            return item;

        }

        public void UpdateItem(Movies item)
        {
            using(SqlConnection con =new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("UPDATE Movies SET Title=@Title, BoxOffice=@Boxoffice,Genre=@Genre, Active=@Active, HasTeaser=@HasTeaser Where ItemId=@ItemId", con);
                command.Parameters.AddWithValue("@ItemId",item.ItemId);
                command.Parameters.AddWithValue("@Title", item.Title);
                command.Parameters.AddWithValue("@BoxOffice", item.BoxOffice);
                command.Parameters.AddWithValue("@Genre", item.Genre);
                command.Parameters.AddWithValue("@Active", item.Active);
                command.Parameters.AddWithValue("@HasTeaser", item.HasTeaser);

                con.Open();
                command.ExecuteNonQuery();
                con.Close();
            }
        }
    }
}
