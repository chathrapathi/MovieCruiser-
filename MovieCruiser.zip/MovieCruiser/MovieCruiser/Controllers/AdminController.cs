﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MovieCruiser.Helper;
using MovieCruiser.Models;

namespace MovieCruiser.Controllers
{
    public class AdminController : Controller
    {
        AdminDataAccessLayer adminObject = new AdminDataAccessLayer();
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult AddNewMovie()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddNewMovie(Movies item)
        {
            if (ModelState.IsValid)
            {
                adminObject.AddItem(item);
                return RedirectToAction("GetAllMovies");
            }
            return View(item);
        }
        [HttpGet]
        public IActionResult GetAllMovies()
        {
            List<Movies> lstItems = new List<Movies>();
            lstItems = adminObject.GetAllMovies().ToList();

            return View(lstItems);
        }

        [HttpGet]
        public IActionResult Update(int? id)
        {
            Movies item = adminObject.GetMovieById(id);
            return View(item);

        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Update(int id,Movies item)
        {
            if (ModelState.IsValid)
            {
                adminObject.UpdateItem(item);
                return RedirectToAction("GetAllMovies");
            }
            return View(item);
        }

        [HttpGet]
        public IActionResult GetMovie(int? id)
        {
            Movies item = adminObject.GetMovieById(id);
            return View(item);
        }

        [HttpGet]
        public IActionResult DeleteMovie(int? id)
        {
            Movies item = adminObject.GetMovieById(id);

            return View(item);
        }

        [HttpPost, ActionName("DeleteMovie")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteMovie(int id)
        {
            adminObject.DeleteMovie(id);
            return RedirectToAction("GetAllMovies");
        }
    }
}