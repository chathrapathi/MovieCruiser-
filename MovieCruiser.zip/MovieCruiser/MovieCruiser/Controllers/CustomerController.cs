﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MovieCruiser.Helper;
using MovieCruiser.Models;

namespace MovieCruiser.Controllers
{
    public class CustomerController : Controller
    {
        CustomerDataAccessLayer customerObject = new CustomerDataAccessLayer();
        AdminDataAccessLayer adminObject = new AdminDataAccessLayer();
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult GetMovies()
        {
            List<Movies> lstItems = new List<Movies>();
            lstItems = adminObject.GetAllMovies().ToList();

            return View(lstItems);
        }
        [HttpGet]
        public IActionResult GetMovie(int? id)
        {
            Movies item = adminObject.GetMovieById(id);
            return View(item);
        }
        [HttpGet]
        public IActionResult AddToFavorite(int? id)
        {
            Movies item = customerObject.GetMovieById(id);
            customerObject.AddToFavorite(item);
            return View(item);
        }
        [HttpGet]
        public IActionResult GetFavoriteMovie()
        {
            List<Favorites> cartList = new List<Favorites>();
            cartList = customerObject.GetFavoriteMovie().ToList();

            return View(cartList);
        }

        [HttpGet]
        public IActionResult DeleteFavoriteMovie(int? id)
        {
            Favorites cart = customerObject.GetCartItemById(id);

            return View(cart);
        }

        [HttpPost, ActionName("DeleteFavoriteMovie")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteFavoriteMovie(int id)
        {
            customerObject.DeleteFavoriteMovie(id);
            return RedirectToAction("GetFavoriteMovie");
        }
    }
}