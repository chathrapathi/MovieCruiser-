﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieCruiser.Models
{
    public class Favorites
    {
        public int CartId { get; set; }
        public string Title { get; set; }
        public string BoxOffice { get; set; }
        public string Genre { get; set; }
        public string Active { get; set; }
        public string HasTeaser { get; set; }
        public int? ItemId { get; set; }

    }
}
